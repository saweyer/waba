notes:
- to compile, make sure necessary files are in .jar or .zip in classpath
(for Mac OS 9.1, uncompressed .zip)

- to build, wababin.Warp c /f 24 waba waba/sys/*.class ...
  result: waba.cls.txt

- create lib via NTK template


Waba VM classes (not Waba SDK*)

www.wabasoft.com

necessary for all Waba apps; used by Waba VM

waba/
	applet/			[note: not in VM; see SDK]
	fx/
		Color
		Font
		FontMetrics
		Graphics
		Image
		ISurface
		Rect
		Sound
		SoundClip
	io/
		Catalog
		File
		SerialPort
		Socket
		Stream
	lang/			[note: not in SDK directly]
		Object
		String
		StringBuffer
	sys/
		Convert
		Time
		Vm
	ui/
		Button
		Check
		Container
		Control
		ControlEvent
		Edit
		Event
		IKeys
		KeyEvent
		Label
		MainWindow
		PenEvent
		Radio
		Tab
		TabBar
		Timer
		Welcome
		Window
	util/
		Vector
java/
	lang/
		Object			== waba/lang/Object
		String			== waba/lang/String
		StringBuffer	== waba/lang/StringBuffer


=====

*the SDK classes used for compiling waba apps,
and for running them with a regular Java VM:

waba/
	applet/			[note: not in VM]
		Applet
		Frame
		WinCanvas
		WinTimer
	fx/				[note: same as VM]
	io/				[note: same as VM]
	lang/			[note: not in SDK; uses java/lang]
	sys/			[note: same as VM]
	ui/				[note: same as VM]
	util/			[note: same as VM]
