package wababin;

public interface ExegenFile {
	public String list(boolean extract);
}