import waba.io.*;
import waba.sys.*;
import waba.fx.*;

public class ConnectException extends Exception
{
  public ConnectException(String msg)
    {
      super(msg);
    }
  
}

